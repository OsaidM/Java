package com.codingdojo.joja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JojaApplicationTests {

	@Test
	void contextLoads() {
	}

}
