package com.codingdojo.joja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JojaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JojaApplication.class, args);
	}

}
