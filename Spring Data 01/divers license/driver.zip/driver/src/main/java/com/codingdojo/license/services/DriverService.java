package com.codingdojo.license.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.codingdojo.license.models.License;
import com.codingdojo.license.models.Person;
import com.codingdojo.license.repositories.DriversRepo;
import com.codingdojo.license.repositories.LicenseRepo;

@Service 
public class DriverService {
	private final DriversRepo driverRepo;
	private final LicenseRepo licenseRepo;
	
 	public DriverService(DriversRepo driverRepo, LicenseRepo licenseRepo) {
 		this.driverRepo=driverRepo;
 		this.licenseRepo=licenseRepo;
	}
 	
 	public Person createPerson(Person person) {
		return this.driverRepo.save(person);
	}
 	
 	public List<Person> getPeople() {
		return driverRepo.findAll();
	}
 	
 	public List<Person> getUnlicensedPeople() {
		return driverRepo.findByNoLicense();
	}
 	
 	public License createLicense(License license) {
 		license.setNumber(this.generateLicenseNumber());
		return licenseRepo.save(license);
	}
 	
 	public int generateLicenseNumber() {
		License license = licenseRepo.findTopByOrderByNumberDesc();
		if(license == null)
			return 1;
		int largestNumber = license.getNumber();
		largestNumber++;
		return (largestNumber);
	}
 	
 	
 	
}
