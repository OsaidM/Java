package com.codingdojo.license.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.codingdojo.license.models.Person;

@Repository
public interface DriversRepo extends CrudRepository<Person,Long>{
	 List<Person> findAll();
	 @Query(value="SELECT p.* FROM persons p LEFT OUTER JOIN license l ON p.id = l.person_id WHERE l.id IS NULL", nativeQuery=true)
	 List<Person> findByNoLicense();
}
