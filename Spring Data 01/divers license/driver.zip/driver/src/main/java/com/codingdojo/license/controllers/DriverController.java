package com.codingdojo.license.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.codingdojo.license.models.License;
import com.codingdojo.license.models.Person;
import com.codingdojo.license.services.DriverService;

@Controller
public class DriverController {
	private final DriverService driverService;
	
	
	public DriverController(DriverService driverService) {
		this.driverService = driverService;
	}
	
	@RequestMapping("/")
	public String index(Model model) {
		List<Person> persons = driverService.getPeople();
		model.addAttribute("persons",persons);
		return "/index.jsp";
		
	}
	
	@RequestMapping("/persons/new")
	public String newDriver(@ModelAttribute("person") Person person) {
		return "/new.jsp";
	}
	
	
	@RequestMapping(value = "/persons/new", method= RequestMethod.POST)
	public String addNewD(@Valid @ModelAttribute("person") Person person, BindingResult result) {
		if(result.hasErrors()) {
			return "/new.jsp";
			
		}else {
			this.driverService.createPerson(person);
			
			return "redirect:/";
		}
	}
	
	@RequestMapping("/license/new")
	public String newLicense(@Valid @ModelAttribute("license") License license,Model model, BindingResult result) {
		if(result.hasErrors()) {
            return "/newlicense.jsp";
        }
		
		List<Person> persons = driverService.getUnlicensedPeople();
		model.addAttribute("persons",persons);
		return "/newlicense.jsp";
	}
	
	@RequestMapping(value = "/license/add", method=RequestMethod.POST)
	public String addLicense(@Valid @ModelAttribute("license") License license, BindingResult result) {
		if(result.hasErrors()) {
            return "/newlicense.jsp";
        } 
		
		driverService.createLicense(license);
		return "redirect:/";
	}
	
	@RequestMapping("/persons/{id}")
	public String newLicense(@PathVariable("id") Long id,Model model) {
		
		List<Person> persons = driverService.getPeople();
		model.addAttribute("persons",persons);
		model.addAttribute("person_id",id);
		return "/details.jsp";
	}
	
}
