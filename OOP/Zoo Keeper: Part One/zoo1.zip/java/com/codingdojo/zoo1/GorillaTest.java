/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codingdojo.zoo1;

/**
 *
 * @author m5pa1k
 */
public class GorillaTest {
    public static void main(String[]args) {
		Gorilla newGorilla = new Gorilla();
		//Mammal newMammal = new Mammal();
		
		newGorilla.throwSomething();
		newGorilla.throwSomething();
		newGorilla.throwSomething();
		
		newGorilla.eatBananas();
		newGorilla.eatBananas();
		
		newGorilla.climb();
		
	}
}
