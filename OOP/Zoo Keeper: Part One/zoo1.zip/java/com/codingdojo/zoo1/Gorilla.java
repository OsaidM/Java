/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codingdojo.zoo1;

/**
 *
 * @author m5pa1k
 */
public class Gorilla {
    Mammal mamal = new Mammal();
	
	public void throwSomething(){
		mamal.energyLevel(-5);
		String ms = "The Gorilla has thrown something";
		mamal.displayEnergy();
		System.out.println(ms);
	}
	
	public void eatBananas(){
		mamal.energyLevel(10);
		String ms = "The Gorilla is so happy:)";
		mamal.displayEnergy();
		System.out.println(ms);
	}
	
	public void climb(){
		mamal.energyLevel(-10);
		String ms = "The Gorilla has climbed a tree";
		mamal.displayEnergy();
		System.out.println(ms);
	}
}
