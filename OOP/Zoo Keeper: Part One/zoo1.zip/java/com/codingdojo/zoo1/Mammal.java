/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codingdojo.zoo1;

/**
 *
 * @author m5pa1k
 */
public class Mammal {
    private int energy = 100;
//	public Mammal(int energy) {
//		this.energy = energy;
//	}
	public Integer energyLevel(int d) {
		this.energy += d;
		return this.energy;
	}
	
	public int displayEnergy() {
		
		int en = this.energy;
		System.out.println(en);
		return en;
	}
}
