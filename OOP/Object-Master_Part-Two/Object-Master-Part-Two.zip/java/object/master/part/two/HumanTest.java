/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object.master.part.two;

/**
 *
 * @author m5pa1k
 */
public class HumanTest {
    public static void main(String [] args){
        Human Osaid = new Human();
        Human lazem = new Human();
        Osaid.attack(lazem);
        System.out.println(lazem.health());
        Wizard newWizard = new Wizard();
        
        newWizard.fireball(lazem);
        System.out.println(lazem.health());
        
        Samurai newSamurai = new Samurai();
        Samurai newSamurai2 = new Samurai();
        Samurai newSamurai3 = new Samurai();
        
        newSamurai.deathBlow(lazem);
        System.out.println(lazem.health() + " <== this human is dead" );
        newSamurai.meditate();
        System.out.println(newSamurai.health());
        newSamurai3.numberOfSamurai();
    }
}
