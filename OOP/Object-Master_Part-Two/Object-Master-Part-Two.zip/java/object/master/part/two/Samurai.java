/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object.master.part.two;

/**
 *
 * @author m5pa1k
 */
public class Samurai extends Human {
    private static int counter = 0;
    public Samurai(){
        this.setHealth(200);
        this.counter += 1;
    }
    
    public void deathBlow(Human otherHuman){
        int otherHealth = otherHuman.health();
        otherHuman.setHealth(otherHealth - otherHealth);
        int samHealth = this.health();
        this.setHealth(samHealth / 2);
    }
    
    public void meditate(){
        int newHealth = this.health() / 2;
        this.setHealth(this.health() + newHealth);
    }
    
    public void numberOfSamurai(){
        System.out.println(counter);
    }
    
}
