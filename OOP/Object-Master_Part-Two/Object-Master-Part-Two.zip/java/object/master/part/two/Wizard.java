/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object.master.part.two;

/**
 *
 * @author m5pa1k
 */
public class Wizard extends Human{
    public Wizard(){
        this.setHealth(50);
        this.setIntelligence(8);
    }
    
    public void heal(Human otherHuman){
        int otherHealth = otherHuman.health();
        otherHuman.setHealth(otherHealth + this.intelligence());
    }
    
    public void fireball(Human otherHuman){
        int otherHealth = otherHuman.health();
        otherHuman.setHealth(otherHealth - this.intelligence() * 3);
    }
}
