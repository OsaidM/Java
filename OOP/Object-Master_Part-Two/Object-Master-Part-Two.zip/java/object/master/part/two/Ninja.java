/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object.master.part.two;

/**
 *
 * @author m5pa1k
 */
public class Ninja extends Human{
    public Ninja(){
        this.setStealth(10);
    }
    
    public void steal(Human otherHuman){
        int otherHealth = otherHuman.health();
        otherHuman.setHealth(otherHealth - this.stealth() );
        this.setHealth(this.health() + this.stealth());
    }
    
    public void runAway(){
        this.setHealth(this.health() - 10);
    }
    
}
