/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codingdojo.zoo2;

/**
 *
 * @author m5pa1k
 */
public class BatTest {
    public static void main(String[]args) {
		Bat newGorilla = new Bat();
		//Mammal newMammal = new Mammal();
		
		newGorilla.attackTown();
                newGorilla.attackTown();
                newGorilla.attackTown();
		
		newGorilla.eatHumans();
		newGorilla.eatHumans();
		
		newGorilla.fly();
                newGorilla.fly();
		
	}
}
