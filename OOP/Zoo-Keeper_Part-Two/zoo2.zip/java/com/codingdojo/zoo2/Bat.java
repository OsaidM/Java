/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codingdojo.zoo2;

/**
 *
 * @author m5pa1k
 */
public class Bat {
    Mammal mamal = new Mammal(300);
	
	public void fly(){
            
		mamal.energyLevel(-50);
		String ms = "sound a bat taking off";
		mamal.displayEnergy();
		System.out.println(ms);
	}
	
	public void eatHumans(){
		mamal.energyLevel(25);
		String ms = "so- well, never mind,:)";
		mamal.displayEnergy();
		System.out.println(ms);
	}
	
	public void attackTown(){
		mamal.energyLevel(-100);
		String ms = "sound of a town on fire";
		mamal.displayEnergy();
		System.out.println(ms);
	}
}
