package com.exam.tvshow.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.tvshow.models.Show;

@Repository
public interface ShowRepository extends CrudRepository<Show, Long> {

}
