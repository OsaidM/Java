package com.categories_products.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoriesProductsApplication {

    public static void main(String[] args) {
        SpringApplication.run(CategoriesProductsApplication.class, args);
    }

}
