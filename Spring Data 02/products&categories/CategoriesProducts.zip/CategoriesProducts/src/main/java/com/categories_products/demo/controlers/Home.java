package com.categories_products.demo.controlers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.categories_products.demo.models.Category;
import com.categories_products.demo.models.CategoryProduct;
import com.categories_products.demo.models.Product;
import com.categories_products.demo.services.ProCatService;

@Controller
public class Home {
    private final ProCatService proCatServ;

    public Home(ProCatService proCatServ) {
        this.proCatServ = proCatServ;
    }

    @RequestMapping("/show/pro")
    public List<Product> getAllProducts() {
        return proCatServ.allProducts();
    }

    @RequestMapping("/show/cat")
    public List<Category> getAllCategories() {
        return proCatServ.allCategories();
    }


    @RequestMapping("/product")
    public String showProducts(@ModelAttribute("prod") Product prod, Model model) {
        List<Product> products = proCatServ.allProducts();
        model.addAttribute("products", products);
        return "newProduct.jsp";
    }

    @RequestMapping(value = "/product/new",method = RequestMethod.POST)
    public String addProduct(@ModelAttribute("prod") Product prod) {
        // Code
        Product p = proCatServ.createProduct(prod);
        return "redirect:/product";
    }
    
    @RequestMapping(value = "/product/add/{id}",method = RequestMethod.POST)
    public String addProductCat(@PathVariable("id") Long id,@RequestParam(value="prod_id") Long pId, @ModelAttribute("categoryProduct")CategoryProduct categoryProduct, BindingResult result) {
    		Product thisProduct = proCatServ.getProduct(id);
    		Category category = proCatServ.getCategory(pId);
    		categoryProduct.setCategory(category);
    		categoryProduct.setProduct(thisProduct);
    		proCatServ.createCategoryProduct(categoryProduct);
    		
        //Product p = proCatServ.createProduct(prod);
        return "redirect:/product/"+ id;
        //return"redirect:/products/"+Id;
    }
    
    @RequestMapping("/product/{id}")
    public String showCategory(@PathVariable("id") Long id,@ModelAttribute("prod") Category cat, Model model) {
    	Product thisOne = proCatServ.getProduct(id);
    	List<Category> others = proCatServ.findCategoriesNotInProduct(thisOne);
    	
    	System.out.println(others);
    	model.addAttribute("product", thisOne);
    	model.addAttribute("notInCategories", others);
    	
    	return "productDetails.jsp";
    }
    
    @RequestMapping("/category")
    public String showCategorys(@ModelAttribute("cat") Category cat, Model model) {
        List<Category> categorys = proCatServ.allCategories();
        model.addAttribute("categorys", categorys);
        return "newCategory.jsp";
    }
    
    @RequestMapping("/category/{id}")
    public String showProducts(@PathVariable("id") Long id,@ModelAttribute("cat") Category cat, Model model) {
    	Category thisOne = proCatServ.getCategory(id);
    	List<Product> others = proCatServ.findProductsNotInCategory(thisOne);
    	
    	
    	model.addAttribute("category", thisOne);
    	model.addAttribute("notInProducts", others);
    	
    	return "categoryDetails.jsp";
    }
    
    @RequestMapping(value = "/create/cat", method = RequestMethod.POST)
    public String createNewCat(@RequestParam("name") String name) {
    	Category cat = proCatServ.createCategory(new Category(name));
    	return "redirect:/category";
    }
    
    @RequestMapping(value = "/category/add/{id}",method = RequestMethod.POST)
    public String addCategoryProd(@PathVariable("id") Long id,@RequestParam(value="cat_id") Long cId, @ModelAttribute("categoryProduct")CategoryProduct categoryProduct, BindingResult result) {
    		Category thisCategory = proCatServ.getCategory(id);
    		Product product = proCatServ.getProduct(cId);
    		categoryProduct.setCategory(thisCategory);
    		categoryProduct.setProduct(product);
    		proCatServ.createCategoryProduct(categoryProduct);
    		
        //Product p = proCatServ.createProduct(prod);
        return "redirect:/category/"+ id;
        //return"redirect:/products/"+Id;
    }
    
    
}
