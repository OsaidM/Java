package com.categories_products.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoriesProductsApplicationTests {

    @Test
    void contextLoads() {
    }

}
