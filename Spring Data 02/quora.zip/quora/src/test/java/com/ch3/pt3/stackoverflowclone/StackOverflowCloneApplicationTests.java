package com.ch3.pt3.stackoverflowclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StackOverflowCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
