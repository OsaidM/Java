package com.codingdojo.osaid;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CounterController {
	
	@RequestMapping("/")
	public String root() {
		
		return "index.jsp";
	}
	
	@RequestMapping(value="/process", method=RequestMethod.POST)
	public String processCode(HttpSession session,@RequestParam(value="name") String name,@RequestParam(value="location") String location,@RequestParam(value="flan") String flan,@RequestParam(value="comment") String comment){
		if(flan.equals("java")) {
			return "redirect:/java";
		}else {
		session.setAttribute("name", name);
		session.setAttribute("location", location);
		session.setAttribute("flan", flan);
		session.setAttribute("comment", comment);
		return "redirect:/result";
		}
	}
	
	@RequestMapping("/result")
	public String counter(HttpSession session, Model model) {
        	String name = (String) session.getAttribute("name");
        	String location = (String) session.getAttribute("location");
        	String flan = (String) session.getAttribute("flan");
        	String comment = (String) session.getAttribute("comment");
        	model.addAttribute(name);
        	model.addAttribute(location);
        	model.addAttribute(flan);
        	model.addAttribute(comment);
		return "result.jsp";
	}
	
	@RequestMapping("/java")
	public String java() {
        	
		return "java.jsp";
	}
	
	
}
