package com.codingdojo.templating;

import java.util.Date;
import java.text.SimpleDateFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class ControllerDemo {
	@RequestMapping("/")
	public String index(Model model) {
		model.addAttribute("dojoName","Osaid");
		return "index.jsp";
		
	}
	
	@RequestMapping("/date")
	public String date(Model model) {
		Date cDate = new Date();
		SimpleDateFormat dFormat = new SimpleDateFormat("EEEE, 'the' dd 'of' MMMM,yyyy");
		model.addAttribute("cDate",dFormat.format(cDate));
		return "date.jsp";
		
	}
	@RequestMapping("/time")
	public String time(Model model) {
		Date ctime = new Date();
		SimpleDateFormat tFormat = new SimpleDateFormat("hh:mm a");
		model.addAttribute("time",tFormat.format(ctime));
		return "time.jsp";
		
	}
}
