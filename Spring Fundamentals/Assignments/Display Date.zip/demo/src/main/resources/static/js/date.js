/**
 * 
 */

alert("this is the date template");