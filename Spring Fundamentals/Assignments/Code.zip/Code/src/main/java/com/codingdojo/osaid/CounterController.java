package com.codingdojo.osaid;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CounterController {
	
	@RequestMapping("/")
	public String root() {
		
		return "index.jsp";
	}
	
	@RequestMapping(value="/code", method=RequestMethod.POST)
	public String processCode(@RequestParam(value="code") String code) {
		if (code.equals("bushido")) {
			return "redirect:/code";
		}else {
			return "redirect:/";
		}
	}
	
	@RequestMapping("/code")
	public String counter() {
        	
		return "code.jsp";
	}
	
	
}
