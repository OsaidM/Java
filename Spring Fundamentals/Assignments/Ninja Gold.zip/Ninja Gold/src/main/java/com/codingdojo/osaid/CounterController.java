package com.codingdojo.osaid;

import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CounterController {
	
	@RequestMapping("/")
	public String root(HttpSession session) {
		if(session.getAttribute("gold") == null){
			session.setAttribute("gold",0);
			session.setAttribute("res","");
		}
		
		return "index.jsp";
	}
	
	@RequestMapping(path="//process_money/{id}", method=RequestMethod.POST)
	public String processCode(HttpSession session,@PathVariable int id){
		
		Random rnd = new Random();
		int gold = 0;
		
		String res = "";
		
		if(id == 1) {
			gold = rnd.nextInt(10)+10;
			res += "You entered a farm and earned " + gold+ " gold ";
		}else if(id == 2) {
			gold = rnd.nextInt(5)+5;
			res += "You entered a cave and earned " + gold+ " gold ";
		}else if(id == 3) {
			gold = rnd.nextInt(3)+2;
			res += "You entered a house and earned " + gold+ " gold ";
		}else if(id == 4) {
			gold = rnd.nextInt(100)-50;
			if(gold < 0) {
				res += "You entered a casino and lost " + gold+ " gold ";
			}else {
				res += "You entered a casino and earned " + gold+ " gold </p>";
			}
		}
		
		session.setAttribute("gold", (Integer) session.getAttribute("gold") + gold);
		session.setAttribute("res", (String) session.getAttribute("res") + res+"\n");
		return "redirect:/";
		
	}
	
	
	
	
	
}
