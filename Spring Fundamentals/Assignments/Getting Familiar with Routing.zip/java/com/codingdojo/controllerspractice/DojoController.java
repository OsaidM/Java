package com.codingdojo.controllerspractice;


import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class DojoController {
	
	
	@RequestMapping("/{dojo}")
    public String root2(@PathVariable("dojo") String s) {
		if(s.equals("dojo")) {
            return "The dojo is " + s ;
		}else if(s.equals("burbank-dojo")) {
			return "Burbank Dojo is located in Southern California";
		}else if(s.equals("san-jose")) {
			return "SJ dojo is the headquarters" ;
			
		}else {
			return "The dojo is  nothing";
		}
    }
}
