public class HelloWorld{
    public static void main(String[] args){
        System.out.println("Osaid");
        System.out.println("I am 25 years old");
        System.out.println("my hometown is sabastiya");
    }

}
